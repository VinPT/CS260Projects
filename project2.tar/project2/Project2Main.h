//This Runs the show
//Written by Vinayaka Patrick Thompson;
//Sources Project1, Project2Description, Project2DriverCode
//https://github.com/caspen/CS260Projects.git

#pragma once

#include <iostream>
#include "HouseStack.h"
#include "HouseQueue.h"
#include "House.h"

using namespace std;

int main();
